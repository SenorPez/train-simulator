To uninstall the **Donner Pass Southern Pacific** scenario package, delete the following file: 

`\Content\Routes\00000032-0000-0000-0000-000000000000\z-donner-pass-southern-pacific.ap`
