> [!CAUTION]
> The **Castle Rock Railroad** scenario package overwrites existing Train Simulator Classic 2024 files.

To backup the files that will be changed, make a **backup copy** (do not move or delete the files) of the following directory:
`\Content\Routes\00000006-0000-0000-0000-000000000000\Scenarios\1c3cbd3d-107a-478a-b4d2-f3a60b226f65`
