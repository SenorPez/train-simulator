To uninstall the **Castle Rock Railroad** scenario package:
1. Delete the following directory: `\Content\Routes\00000006-0000-0000-0000-000000000000\Scenarios\1c3cbd3d-107a-478a-b4d2-f3a60b226f65`
2. Restore the backup copy of that was made prior to installation to the same location.
