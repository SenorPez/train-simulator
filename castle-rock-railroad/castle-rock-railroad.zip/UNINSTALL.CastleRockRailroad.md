To uninstall the **Castle Rock Railroad** scenario package:

1. Delete the following directories: 
* `\Content\Routes\00000006-0000-0000-0000-000000000000\Scenarios\1c3cbd3d-107a-478a-b4d2-f3a60b226f65`
* `\Content\Routes\00000006-0000-0000-0000-000000000000\Scenarios\e788dc70-c7ff-4c29-bd77-5711c6c4164d`

2. Restore the backup copies of the directories that were made prior to installation.
