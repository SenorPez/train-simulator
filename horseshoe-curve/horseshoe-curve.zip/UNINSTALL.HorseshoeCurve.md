To uninstall the **Horseshoe Curve** scenario package:

1. Delete the following directories: 
* `\Content\Routes\00000025-0000-0000-0000-000000000000\Scenarios\98f752f1-553f-46e6-8499-3d49269c1cf0`

2. Restore the backup copies of the directories that were made prior to installation.
