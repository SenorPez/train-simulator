To uninstall the **Horseshoe Curve** scenario package:

1. Delete the following directories: 
* `\Content\Routes\00000025-0000-0000-0000-000000000000\Scenarios\98f752f1-553f-46e6-8499-3d49269c1cf0`
* `\Content\Routes\00000025-0000-0000-0000-000000000000\Scenarios\520363bc-f7f7-491d-95e3-54bcfb0826fb`

2. Restore the backup copies of the directories that were made prior to installation.
