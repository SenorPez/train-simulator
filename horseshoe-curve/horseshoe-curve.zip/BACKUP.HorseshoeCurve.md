> [!CAUTION]
> The **Horseshoe Curve** scenario package overwrites existing Train Simulator Classic 2024 files.

To backup the files that will be changed, make a backup **copy** (do not move or delete the files, not all are updated by the package) of the following directories:

* `\Content\Routes\00000025-0000-0000-0000-000000000000\Scenarios\98f752f1-553f-46e6-8499-3d49269c1cf0`
